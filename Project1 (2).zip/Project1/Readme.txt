Arduino Project:

The Environment used is provided by VS-code: Platform.io

To run the code Platform.io should be installed.
SRC folder contains the main.cpp file.
Other used API are located in lib.
