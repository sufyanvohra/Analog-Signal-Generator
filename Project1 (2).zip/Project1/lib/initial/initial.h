#include "Arduino.h"


#ifndef INITIAL_H
#define INITIAL_H

void SYS_Initialize( void  );

#endif