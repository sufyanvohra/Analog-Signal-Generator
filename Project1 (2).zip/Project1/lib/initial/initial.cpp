
#include "Arduino.h"
#include <stdio.h>
#include "Timerblock.h"
#include "periodicTimer.h"
#include "PWMblock.h"
#include "periodicNpulse.h"
#include "ADC_block.h"


//Initializinf all APIS

void SYS_Initialize( void )
{ 
    timer_sys_init();  
    timer_periodic_init();
    npulse_pwm_int();
    npulse_periodic_init();
    ADC_init();

}
