#include "Arduino.h"
#include <stdio.h>
#include "periodicNpulse.h"
#include "periodicTimer.h"
#include "PWMblock.h"


static volatile bool timerbool3 = false;


static int period_ms1;
float frequency;
int pulseC;



// Due to the use of Library nothing to innitialize
int npulse_periodic_init(void){
    return 0;
}


// To generate Npulse periodic with a period. PWM pulses are generated in the call back function 
int npulse_periodic_start(float freq, int pulse_cnt ,  int period_ms){

    if (timerbool3 == false){

    timerbool3 = true;

    frequency = freq;
    pulseC = pulse_cnt;
    period_ms1 = period_ms;


    npulse_pwm_start(frequency, pulseC);
    timer_periodic_start(period_ms);
    timer_periodic_subscribe_callback(timerCallback);


    }
 return 0;
}


void npulse_periodic_stop(void){

    if (timerbool3 == true){
    timerbool3 = true;

    npulse_pwm_stop();
    timer_periodic_stop();
}
}
int npulse_periodic_is_running(void){

    if(timerbool3 == 1){return 1;}
    else {return 0;}

}

// Starting PWM funciton
 void timerCallback(void) {
    npulse_pwm_start(frequency, pulseC);
}





