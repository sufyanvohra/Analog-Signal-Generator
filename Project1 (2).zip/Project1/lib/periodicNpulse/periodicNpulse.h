#include "Arduino.h"

#include <stdbool.h>

#ifndef periodicNpulse_h
#define periodicNpulse_h

int npulse_periodic_init(void);
int npulse_periodic_start(float freq, int pulse_cnt, int period_ms);
void npulse_periodic_stop(void);
int npulse_periodic_is_running(void);
void timerCallback(void);
 void timer2delay(void);

#endif