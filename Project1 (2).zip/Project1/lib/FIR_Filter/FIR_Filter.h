#include "Arduino.h"

#include <stdio.h>

#ifndef FIRFILTER_h
#define FIRFILTER_h

void filter_signal(int ustime);


#endif 