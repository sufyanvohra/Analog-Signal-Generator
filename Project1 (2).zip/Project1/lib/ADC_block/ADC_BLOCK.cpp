#include <Arduino.h>
#include "Timerblock.h"
#include "periodicTimer.h"
#include <EEPROM.h>


static int ADC_SAMPLE_TIME;
int value_1024; 

int tempPin = 0;      //the ADC pin
int address = 0;      //EEPROM address counter

static volatile bool ADC_running = false;

unsigned long timer;

float conv_coeff = 255.0/1024.0;   // Coeff to scale to 255



// Clearinf the EEProm memory block
int ADC_init(void){

    for (int i = 0 ; i < 1024 ; i++) {
        if(EEPROM.read(i) != 0)                    //skip already "empty" addresses
        {
         EEPROM.write(i, 0);                       //write 0 to address i
        }
  }
  address = 0; 
  return 0;
}


// Sample time 
int ADC_set_sample_time(int sample_us){

    ADC_SAMPLE_TIME = sample_us;
    return 0 ;
}


// Value is read with Sampling frequency and Stored in EEPROM

void ADC_start(void){

    if(ADC_running == false){
    ADC_running = true;

    while(address <  1024){      //EEPROM is 1kb
        if(timer_sys_get_time_us() - timer > ADC_SAMPLE_TIME){


        float val = analogRead(tempPin);  



        value_1024 = val*conv_coeff;
        byte value = value_1024;

        EEPROM.write(address, value);
        address++;                      //increment address counter
        timer = timer_sys_get_time_us();
        }
    }
    }

  }

void ADC_stop(void){


}

int ADC_is_running(void){
    if (ADC_running){return 1;}
    else {return 0;}
    return 0;
}

// ADC call back funciton
int ADC_set_complete_callback(void(*callback)(char *p_src, int len)){

    return 0;

}