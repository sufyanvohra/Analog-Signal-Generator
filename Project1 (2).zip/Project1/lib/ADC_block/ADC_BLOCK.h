#include "Arduino.h"

#include <stdbool.h>

#ifndef ADC_BLOCK_H
#define ADC_BLOCK_H

int ADC_init(void);
int ADC_set_sample_time(int sample_us);
void ADC_start(void);
void ADC_stop(void);
int ADC_is_running(void);
int ADC_set_complete_callback(void(*callback)(void));



#endif