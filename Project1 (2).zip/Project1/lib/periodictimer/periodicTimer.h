#include "Arduino.h"

#include <stdbool.h>

#ifndef PERIODICTIMER_h
#define PERIODICTIMER_H

int timer_periodic_init(void);
int timer_periodic_subscribe_callback(void(*callback)(void));
int timer_periodic_start(int period_ms);
void timer_periodic_stop(void);
void timer_periodic_is_running(void);
#endif