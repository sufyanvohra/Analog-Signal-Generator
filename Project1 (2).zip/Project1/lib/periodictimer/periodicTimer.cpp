
#include "Arduino.h"
#include <stdio.h>
#include "periodicTimer.h"


float timerPeriod;
int timerPeriod2;

static int count = 0;
float timerHz;

extern int periodic_timer_status;
static volatile bool timerbool_p = false;
static volatile bool overflow = false;


static int32_t inter_count;


static void (*isrCallback)();  



// Interrupt for Timer 0

ISR(TIMER0_COMPA_vect)
{

  if (overflow = true){

    if (count <= inter_count){
      count++;
    }
    else{
    isrCallback();
    count = 0;
    }
  }
  else{isrCallback();}

}

int timer_periodic_init(void){

  TCCR0A = 0; // set entire TCCR0A register to 0
  TCCR0B = 0; // same for TCCR0B
  TCNT0  = 0; //initialize counter value to 0

    return 0;
}
int timer_periodic_subscribe_callback(void(*callback)(void)){

    isrCallback = callback;      //Call back function is set
    TIMSK0 |= (1 << OCIE0A);
    return 0;

}
int timer_periodic_start(int period_ms){

  TCCR0A = 0;// set entire TCCR0A register to 0
  TCCR0B = 0;// same for TCCR0B
  TCNT0  = 0;//initialize counter value to 0

    if (timerbool_p == false){

    cli();//stop interrupts

    timerbool_p = true;

    timerHz = 1.0/(period_ms/1000.0);
    timerPeriod = (16000000.0) / (timerHz*1024.0) - 1 ; 
    timerPeriod2 = timerPeriod;

    if (timerPeriod>255){

        inter_count = timerPeriod/255;
        OCR0A = 255;// = (16*10^6) / (1*1024) - 1 (must be <65536
        overflow = true;
    }
    else{
      OCR0A = timerPeriod2;
      overflow = false;
    }

  // set compare match register for 1hz increments
    TCCR0A |= (1 << WGM01);
  // Set CS12 and CS10 bits for 1024 prescaler
    TCCR0B |= (1 << CS02) | (1 << CS00);  
  // enable timer compare interrupt
    sei();
    }
    return 0;
}
void timer_periodic_stop(void){

    if (timerbool_p == true){
    TIMSK0 = 0;
    timerbool_p == false;
    overflow = false;
    count = 0;
    }
}
void timer_periodic_is_running(void){
    if (timerbool_p == true){ periodic_timer_status = 1;}  
    else{periodic_timer_status = 1; }

}





