#include "Arduino.h"
#include <stdio.h>
#include <TimerOne.h>
#include "PWMblock.h"


unsigned long freq_period;

int pulses;
static int counter = 0;

int static check = 0;
static  bool volatile timerbool = false;


int npulse_pwm_int(void){

return 0;
}
int npulse_pwm_start(float freq, int pulse_cnt){

    check = 1;

    if (timerbool == false){
        timerbool = true;
        pulses = pulse_cnt;
        freq_period = (1.0/freq)*1000000.0;
        Timer1.pwm(30,((50.0/100.0)*1023.0),freq_period);  //Using Timer1 library to generate PWM with 50% duty cycle
        Timer1.attachInterrupt(countPulses);
}
return 0;
}

void npulse_pwm_stop(void){

    check = 0;

    if (timerbool == true){
    timerbool = false;
    Timer1.disablePwm(10);
    Timer1.detachInterrupt();
    }
}
int npulse_pwm_is_running(void){

    if(check == 1){return 1;}
    else {return 0;}

}
void countPulses(void){
    if (counter<=pulses){
        counter++;
    }
    else if(counter>pulses){
        counter = 0;
        npulse_pwm_stop();
    }
}

