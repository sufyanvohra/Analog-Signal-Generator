#include "Arduino.h"

#include <stdbool.h>

#ifndef PWMBLOCK_H
#define PWMBLOCK_H

int npulse_pwm_int(void);
int npulse_pwm_start(float freq, int pulse_cnt);
void npulse_pwm_stop(void);
int npulse_pwm_is_running(void);
void countPulses(void);

#endif