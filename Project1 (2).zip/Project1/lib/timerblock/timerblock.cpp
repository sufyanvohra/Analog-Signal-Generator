

#include "Arduino.h"
#include <stdio.h>
#include <TimerOne.h>
#include "Timerblock.h"



static int64_t time_ms = 0;
static volatile bool timerbool = false;

static float timer_us;
static int64_t timer_us_return;

extern int timer1_status= 0;



ISR(TIMER2_COMPA_vect){
    time_ms++;
}

void timer_sys_init(void){

  TCCR2A = 0;// set entire TCCR2A register to 0
  TCCR2B = 0;// same for TCCR2B
  TCNT2  = 0;//initialize counter value to 0

}

void timer_sys_start(void){

    if (timerbool == false){
        cli();//stop interrupts

        timerbool = true;

        OCR2A = 249;
        TCCR2A |= (1 << WGM21);
        // enable timer compare interrupt
        TCCR2B |= (1 << CS22);   
        TIMSK2 |= (1 << OCIE2A);

    }
    sei();//Allow interrupts

}

void timer_sys_stop(void){

  if (timerbool == true){
    TIMSK2 = 0;
    timerbool = false;
    TCCR2B = 0;// same for TCCR2B
    }

}

void timer_sys_is_running(void){
    if (timerbool == true){ timer1_status = 1;}  
    else{timer1_status = 0; }
    
}

int64_t timer_sys_get_time_us(void){

   timer_us = (TCNT2+1.0/(250000.0))*1000000;
   timer_us_return = (time_ms*1000.0) + timer_us;

    return timer_us_return;
}


