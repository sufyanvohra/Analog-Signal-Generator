#include "Arduino.h"

#include <stdbool.h>

#ifndef TIMERBLOCK_H
#define TIMERBLOCK_H

void timer_sys_init(void);
void timer_sys_start(void);
void timer_sys_stop(void);
void timer_sys_is_running(void);
int64_t timer_sys_get_time_us(void);
#endif